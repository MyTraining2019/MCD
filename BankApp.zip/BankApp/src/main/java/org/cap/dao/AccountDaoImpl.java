package org.cap.dao;

import org.cap.dto.Account;
import org.cap.dto.Customer;

public class AccountDaoImpl implements AccountDao{

	@Override
	public boolean createAccount(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findAccountById(int accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
